-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2023 at 12:46 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bp2_uts`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `harga` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `keterangan` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `barang`:
--

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `harga`, `stock`, `kategori`, `keterangan`) VALUES
(17001, 'Indomie Goreng Original', 3300, 15, 'Indomie', 'Variant Goreng Original'),
(17002, 'Indomie Ayam Special', 3500, 37, 'Indomie', 'Variant Kuah Ayam Special'),
(17003, 'Indomie Goreng Jumbo', 10000, 10, 'Indomie', 'Variant Jumbo'),
(17004, 'Indomie Mi Goreng Aceh', 3700, 10, 'Indomie', 'Variant Kuliner Aceh'),
(17005, 'Indomie Real Meat Pepper Chicken', 5000, 50, 'Indomie', 'Lini produk Indomie yang satu ini menggunakan daging berbumbu asli yang tinggal ditaburkan pada mi. Sementara mi yang digunakan adalah mi keriting pip'),
(17006, 'Indomie Real Meat Bakmi', 6000, 12, 'Real Meat', 'Varian Bakmi'),
(17007, 'Nasi Ayam', 8000, 5, 'makanan', 'nasi pake ayam'),
(17008, 'Nasi Goreng', 14000, 6, 'makanan', 'nasi di goreng'),
(17009, 'Kecap iga', 17000, 30, 'Makanan', 'Makanan iga'),
(17013, 'Indomie Real Meat Kambing', 3000, 10, 'Real Meat', 'Varian Kambing'),
(17016, 'dhduashd', 6000, 77, 'insidai', 'sdasbsk');

-- --------------------------------------------------------

--
-- Table structure for table `daftarmenu`
--

CREATE TABLE `daftarmenu` (
  `id_kue` varchar(10) NOT NULL,
  `nama_kue` varchar(20) NOT NULL,
  `harga_kue` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `daftarmenu`:
--

--
-- Dumping data for table `daftarmenu`
--

INSERT INTO `daftarmenu` (`id_kue`, `nama_kue`, `harga_kue`) VALUES
('1', 'Kue Nastar', 80000),
('2', 'Kue Lapis', 150000),
('3', 'Kue Lidah Kucing', 100000),
('4', 'telur gajah', 46000),
('5', 'pluntir', 15000),
('6', 'onde onde', 9000);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Nama` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `login`:
--

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Nama`, `Password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `id_member` int(6) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `member`:
--

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id_member`, `name`) VALUES
(146001, 'Shuya'),
(146002, 'Rynk'),
(146003, 'Lynn'),
(146004, 'hola'),
(146005, 'Hmmm'),
(146006, 'Alhamdulillah'),
(146007, 'Test'),
(146008, 'Register Kesekian kali'),
(146009, 'iuahdbiashf'),
(146010, 'uabsdus'),
(146011, 'qwert');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE `pembelian` (
  `id_pembelian` int(11) NOT NULL,
  `nama_pembeli` varchar(100) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `harga_barang` int(11) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL,
  `pembayaran` int(11) NOT NULL,
  `kembali` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `pembelian`:
--

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `nama_pembeli`, `nama_barang`, `harga_barang`, `jumlah_barang`, `total_harga`, `pembayaran`, `kembali`) VALUES
(902002, 'hola', 'Indomie Goreng Jumbo', 10000, 4, 40000, 50000, 10000),
(902006, 'Shuya', 'Indomie Real Meat Pepper Chicken', 5000, 5, 25000, 30000, 5000),
(902007, 'Rynk', 'Indomie Real Meat Pepper Chicken', 5000, 10, 50000, 100000, 50000),
(902008, 'Lynn', 'test', 1999, 1, 1999, 3000, 1001),
(902009, 'Register Kesekian kali', 'Indomie Real Meat Pepper Chicken', 5000, 5, 25000, 100000, 75000),
(902010, 'Shuya', 'Nasi Ayam', 8000, 2, 16000, 20000, 4000),
(902011, 'Alhamdulillah', 'Indomie Real Meat Bakmi', 6000, 3, 18000, 20000, 2000),
(902012, 'Shuya', 'Indomie Goreng Original', 3300, 3, 9900, 40000, 30100),
(902013, 'iuahdbiashf', 'test', 1999, 2, 3998, 5000, 1002),
(902014, 'hola', 'Nasi Goreng', 14000, 3, 42000, 100000, 58000),
(902015, 'Alhamdulillah', 'Indomie Mi Goreng Aceh', 3700, 40, 148000, 500000, 352000),
(902016, 'Shuya', 'Indomie Goreng Jumbo', 10000, 4, 40000, 50000, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id_pembelian` int(10) NOT NULL,
  `nama_kue` varchar(30) NOT NULL,
  `harga_kue` varchar(30) NOT NULL,
  `jumlah_kue` varchar(30) NOT NULL,
  `total_harga` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `transaksi`:
--

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id_pembelian`, `nama_kue`, `harga_kue`, `jumlah_kue`, `total_harga`) VALUES
(126, 'telur gajah', '46000', '5', 230000),
(192, 'Kue Lapis', '150000', '500', 75000000),
(199, 'Kue Lidah Kucing', '100000', '5', 500000),
(232, 'Kue Nastar', '80000', '5', 400000),
(244, 'Kue Lapis', '150000', '2', 300000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `daftarmenu`
--
ALTER TABLE `daftarmenu`
  ADD PRIMARY KEY (`id_kue`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Nama`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id_member`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_pembelian`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17017;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `id_member` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146012;

--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id_pembelian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=902018;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
